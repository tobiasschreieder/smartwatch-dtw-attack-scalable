# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+temp+acc' 
* Preferred test-window-size: '100' (decision based on smallest k) 
## Precision@k table: 
| k |100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 1000 | 1100 | 1200 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.115 | 0.1 | 0.109 | 0.103 | 0.097 | 0.091 | 0.089 | 0.078 | 0.082 | 0.104 | 0.109 | 0.093 | 
| 3 | 0.255 | 0.244 | 0.256 | 0.268 | 0.259 | 0.258 | 0.257 | 0.252 | 0.261 | 0.259 | 0.243 | 0.26 | 
| 5 | 0.427 | 0.404 | 0.404 | 0.43 | 0.427 | 0.421 | 0.416 | 0.409 | 0.404 | 0.4 | 0.4 | 0.416 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

