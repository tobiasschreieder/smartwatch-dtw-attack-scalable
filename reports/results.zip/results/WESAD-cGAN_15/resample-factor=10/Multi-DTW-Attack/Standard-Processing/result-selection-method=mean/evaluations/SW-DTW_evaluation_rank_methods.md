# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.082 | 0.105 | 0.093 |
| 3 | 0.257 | 0.267 | 0.262 |
| 5 | 0.397 | 0.424 | 0.411 |
| max@k | k = 15 | k = 15 | k = 15 |

