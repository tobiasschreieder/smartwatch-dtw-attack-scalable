# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+temp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.127 | 0.068 | 0.108 | 0.071 | 0.072 | 0.122 | 0.106 | 0.102 | 0.071 | 0.058 | 0.128 | 0.082 | 0.131 | 0.108 | 0.112 | 
| 3 | 0.284 | 0.228 | 0.231 | 0.258 | 0.264 | 0.268 | 0.287 | 0.223 | 0.229 | 0.243 | 0.276 | 0.262 | 0.268 | 0.237 | 0.278 | 
| 5 | 0.482 | 0.35 | 0.354 | 0.387 | 0.384 | 0.429 | 0.407 | 0.421 | 0.386 | 0.374 | 0.446 | 0.451 | 0.419 | 0.426 | 0.481 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

