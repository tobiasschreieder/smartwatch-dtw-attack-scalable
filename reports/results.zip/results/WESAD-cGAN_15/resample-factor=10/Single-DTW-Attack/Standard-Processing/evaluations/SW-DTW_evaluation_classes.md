# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.067 | 0.092 |
| 3 | 0.206 | 0.307 |
| 5 | 0.376 | 0.48 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.08 | 0.074 |
| 3 | 0.257 | 1.0 |
| 5 | 0.428 | 0.406 |
| max@k | k = 15 | k = 15 |

