# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.118 | 0.051 | 0.072 | 0.045 | 0.058 | 0.084 | 0.087 | 0.072 | 0.076 | 0.031 | 0.089 | 0.097 | 0.074 | 0.06 | 0.1 | 
| 3 | 0.285 | 0.219 | 0.186 | 0.214 | 0.271 | 0.204 | 0.284 | 0.231 | 0.201 | 0.185 | 0.24 | 0.271 | 0.242 | 0.238 | 0.258 | 
| 5 | 0.474 | 0.414 | 0.306 | 0.366 | 0.42 | 0.416 | 0.415 | 0.381 | 0.416 | 0.338 | 0.446 | 0.427 | 0.416 | 0.409 | 0.45 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

