# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.074 | 0.079 | 0.077 |
| 3 | 0.25 | 0.256 | 0.253 |
| 5 | 0.406 | 0.428 | 0.417 |
| max@k | k = 15 | k = 15 | k = 15 |

