# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.25 | 0.125 | 0.059 | 0.147 | 0.267 | 0.205 | 0.303 | 0.094 | 0.17 | 0.136 | 0.192 | 0.291 | 0.249 | 0.151 | 0.233 | 
| 3 | 0.563 | 0.314 | 0.245 | 0.298 | 0.53 | 0.419 | 0.566 | 0.3 | 0.344 | 0.258 | 0.441 | 0.502 | 0.447 | 0.285 | 0.443 | 
| 5 | 0.78 | 0.484 | 0.403 | 0.446 | 0.687 | 0.599 | 0.703 | 0.454 | 0.502 | 0.424 | 0.585 | 0.64 | 0.6 | 0.446 | 0.577 | 
| max@k | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

