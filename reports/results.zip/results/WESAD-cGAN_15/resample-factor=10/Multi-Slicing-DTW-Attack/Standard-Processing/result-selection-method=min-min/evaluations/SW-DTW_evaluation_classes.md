# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.214 | 0.136 |
| 3 | 0.423 | 0.333 |
| 5 | 0.576 | 0.504 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.175 | 0.191 |
| 3 | 0.378 | 1.0 |
| 5 | 0.54 | 0.555 |
| max@k | k = 15 | k = 15 |

