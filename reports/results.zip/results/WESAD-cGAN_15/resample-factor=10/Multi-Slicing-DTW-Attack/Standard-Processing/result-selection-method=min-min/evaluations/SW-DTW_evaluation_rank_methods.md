# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.148 | 0.175 | 0.161 |
| 3 | 0.383 | 0.378 | 0.38 |
| 5 | 0.537 | 0.54 | 0.539 |
| max@k | k = 15 | k = 15 | k = 15 |

