# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '500' (decision based on smallest k) 
## Precision@k table: 
| k |100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 1000 | 1100 | 1200 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.183 | 0.243 | 0.227 | 0.24 | 0.246 | 0.179 | 0.143 | 0.167 | 0.144 | 0.14 | 0.154 | 0.23 | 
| 3 | 0.421 | 0.464 | 0.446 | 0.483 | 0.464 | 0.388 | 0.301 | 0.395 | 0.352 | 0.297 | 0.326 | 0.425 | 
| 5 | 0.584 | 0.599 | 0.551 | 0.635 | 0.645 | 0.595 | 0.465 | 0.561 | 0.569 | 0.482 | 0.456 | 0.522 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

