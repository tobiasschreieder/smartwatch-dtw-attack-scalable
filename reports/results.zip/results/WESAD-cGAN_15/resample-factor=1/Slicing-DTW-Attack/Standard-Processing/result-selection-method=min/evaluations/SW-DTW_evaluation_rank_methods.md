# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.858 | 0.951 | 0.905 |
| 3 | 0.96 | 0.973 | 0.967 |
| 5 | 0.984 | 0.987 | 0.986 |
| max@k | k = 12 | k = 13 | k = 13 |

