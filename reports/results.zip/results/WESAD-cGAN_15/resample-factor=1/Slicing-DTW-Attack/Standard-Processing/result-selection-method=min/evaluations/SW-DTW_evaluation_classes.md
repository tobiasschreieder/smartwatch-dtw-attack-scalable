# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.944 | 0.959 |
| 3 | 0.964 | 0.982 |
| 5 | 0.98 | 0.994 |
| max@k | k = 13 | k = 9 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.952 | 0.948 |
| 3 | 0.973 | 1.0 |
| 5 | 0.987 | 0.984 |
| max@k | k = 12 | k = 13 |

