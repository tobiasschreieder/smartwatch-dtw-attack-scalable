# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'temp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.272 | 1.0 | 1.0 | 1.0 | 0.991 | 0.978 | 0.993 | 1.0 | 1.0 | 1.0 | 0.995 | 0.997 | 0.997 | 1.0 | 0.997 | 
| 3 | 0.562 | 1.0 | 1.0 | 1.0 | 0.996 | 0.995 | 0.996 | 1.0 | 1.0 | 1.0 | 0.997 | 0.997 | 0.997 | 1.0 | 0.997 | 
| 5 | 0.784 | 1.0 | 1.0 | 1.0 | 0.997 | 0.996 | 0.997 | 1.0 | 1.0 | 1.0 | 0.997 | 0.997 | 0.997 | 1.0 | 0.999 | 
| max@k | k = 14 | k = 1 | k = 1 | k = 1 | k = 11 | k = 13 | k = 11 | k = 1 | k = 1 | k = 1 | k = 8 | k = 7 | k = 8 | k = 1 | k = 6 | 

