# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '1000' (decision based on smallest k) 
## Precision@k table: 
| k |1000 | 2000 | 3000 | 4000 | 5000 | 6000 | 7000 | 8000 | 9000 | 10000 | 11000 | 12000 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.115 | 0.1 | 0.107 | 0.1 | 0.099 | 0.089 | 0.091 | 0.074 | 0.079 | 0.102 | 0.11 | 0.097 | 
| 3 | 0.253 | 0.243 | 0.253 | 0.267 | 0.257 | 0.261 | 0.254 | 0.249 | 0.256 | 0.268 | 0.249 | 0.259 | 
| 5 | 0.426 | 0.404 | 0.404 | 0.431 | 0.422 | 0.421 | 0.413 | 0.409 | 0.41 | 0.401 | 0.394 | 0.416 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

