# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.129 | 0.068 | 0.11 | 0.071 | 0.073 | 0.122 | 0.109 | 0.09 | 0.071 | 0.058 | 0.124 | 0.084 | 0.129 | 0.11 | 0.108 | 
| 3 | 0.284 | 0.228 | 0.231 | 0.251 | 0.262 | 0.271 | 0.292 | 0.222 | 0.225 | 0.246 | 0.277 | 0.261 | 0.264 | 0.236 | 0.286 | 
| 5 | 0.482 | 0.35 | 0.354 | 0.391 | 0.386 | 0.422 | 0.413 | 0.408 | 0.38 | 0.374 | 0.442 | 0.464 | 0.42 | 0.423 | 0.48 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

