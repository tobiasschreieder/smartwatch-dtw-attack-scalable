# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.086 | 0.123 |
| 3 | 0.241 | 0.292 |
| 5 | 0.397 | 0.452 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.104 | 0.097 |
| 3 | 0.266 | 1.0 |
| 5 | 0.424 | 0.413 |
| max@k | k = 15 | k = 15 |

