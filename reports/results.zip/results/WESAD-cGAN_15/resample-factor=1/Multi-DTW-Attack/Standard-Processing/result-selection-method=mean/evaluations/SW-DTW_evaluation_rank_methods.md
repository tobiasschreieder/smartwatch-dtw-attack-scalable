# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.082 | 0.105 | 0.093 |
| 3 | 0.255 | 0.266 | 0.261 |
| 5 | 0.401 | 0.424 | 0.412 |
| max@k | k = 15 | k = 15 | k = 15 |

