# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Calculated with test-window-size: '1000' 
## Precision@k table: 
| k | DTW-results | sensor weighted | random guess |
|---|---|---|---|
| 1 | 0.126 | 0.286 | 0.067 |
| 3 | 0.289 | 0.486 | 0.2 |
| 5 | 0.436 | 0.686 | 0.333 |
| max@k | k = 15 | k = 8 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.0 | 0.4 | 0.4 | 
| 1 | 0.2 | 0.2 | 0.4 | 0.2 | 
| 1 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 1 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 1 | 0.8 | 0.0 | 0.0 | 0.2 | 
| 3 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 3 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 5 | 0.4 | 0.0 | 0.4 | 0.2 | 
| 5 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 5 | 0.4 | 0.4 | 0.0 | 0.2 | 
| 5 | 0.6 | 0.0 | 0.0 | 0.4 | 
| 5 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 5 | 0.6 | 0.2 | 0.2 | 0.0 | 
### Table for method: 'stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.2 | 0.4 | 0.2 | 
| 1 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 1 | 0.4 | 0.4 | 0.0 | 0.2 | 
| 3 | 0.2 | 0.2 | 0.0 | 0.6 | 
| 3 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 3 | 0.2 | 0.2 | 0.4 | 0.2 | 
| 3 | 0.2 | 0.2 | 0.6 | 0.0 | 
| 3 | 0.4 | 0.4 | 0.0 | 0.2 | 
| 3 | 0.4 | 0.4 | 0.2 | 0.0 | 
| 5 | 0.4 | 0.4 | 0.0 | 0.2 | 

