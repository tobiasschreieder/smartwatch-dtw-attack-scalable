# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.073 | 0.079 | 0.076 |
| 3 | 0.252 | 0.256 | 0.254 |
| 5 | 0.404 | 0.428 | 0.416 |
| max@k | k = 15 | k = 15 | k = 15 |

