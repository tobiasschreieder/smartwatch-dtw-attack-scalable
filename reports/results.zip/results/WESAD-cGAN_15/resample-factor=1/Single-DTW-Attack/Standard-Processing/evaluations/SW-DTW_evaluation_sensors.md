# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.117 | 0.05 | 0.077 | 0.044 | 0.058 | 0.085 | 0.086 | 0.073 | 0.073 | 0.032 | 0.089 | 0.098 | 0.07 | 0.06 | 0.095 | 
| 3 | 0.285 | 0.218 | 0.186 | 0.212 | 0.266 | 0.205 | 0.287 | 0.23 | 0.201 | 0.181 | 0.236 | 0.265 | 0.239 | 0.241 | 0.26 | 
| 5 | 0.474 | 0.412 | 0.299 | 0.371 | 0.417 | 0.407 | 0.415 | 0.38 | 0.416 | 0.339 | 0.449 | 0.434 | 0.408 | 0.41 | 0.455 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

