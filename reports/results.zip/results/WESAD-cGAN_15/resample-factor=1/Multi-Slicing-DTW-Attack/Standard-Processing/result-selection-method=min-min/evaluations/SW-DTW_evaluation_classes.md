# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.217 | 0.132 |
| 3 | 0.428 | 0.331 |
| 5 | 0.576 | 0.499 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.174 | 0.192 |
| 3 | 0.38 | 1.0 |
| 5 | 0.537 | 0.554 |
| max@k | k = 15 | k = 15 |

