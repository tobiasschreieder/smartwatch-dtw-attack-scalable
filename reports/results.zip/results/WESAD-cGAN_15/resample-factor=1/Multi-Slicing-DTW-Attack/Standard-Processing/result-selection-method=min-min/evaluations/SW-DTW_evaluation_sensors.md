# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.259 | 0.126 | 0.059 | 0.125 | 0.255 | 0.211 | 0.302 | 0.114 | 0.18 | 0.13 | 0.207 | 0.291 | 0.243 | 0.145 | 0.241 | 
| 3 | 0.562 | 0.329 | 0.234 | 0.296 | 0.528 | 0.433 | 0.555 | 0.303 | 0.342 | 0.27 | 0.447 | 0.494 | 0.462 | 0.301 | 0.443 | 
| 5 | 0.76 | 0.47 | 0.41 | 0.45 | 0.689 | 0.594 | 0.701 | 0.45 | 0.478 | 0.436 | 0.578 | 0.663 | 0.582 | 0.453 | 0.592 | 
| max@k | k = 13 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

