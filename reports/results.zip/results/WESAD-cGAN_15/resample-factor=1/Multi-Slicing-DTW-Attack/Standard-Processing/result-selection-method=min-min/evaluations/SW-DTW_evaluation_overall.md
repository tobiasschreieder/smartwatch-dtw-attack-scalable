# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Calculated with test-window-size: '2000' 
## Precision@k table: 
| k | DTW-results | sensor weighted | random guess |
|---|---|---|---|
| 1 | 0.25 | 0.523 | 0.067 |
| 3 | 0.458 | 0.694 | 0.2 |
| 5 | 0.596 | 0.848 | 0.333 |
| max@k | k = 15 | k = 8 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.4 | 0.0 | 0.4 | 
| 1 | 0.2 | 0.4 | 0.2 | 0.2 | 
| 1 | 0.2 | 0.6 | 0.0 | 0.2 | 
| 3 | 0.2 | 0.4 | 0.0 | 0.4 | 
| 3 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 3 | 0.4 | 0.2 | 0.0 | 0.4 | 
| 3 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 3 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 3 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 5 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 5 | 0.2 | 0.4 | 0.0 | 0.4 | 
| 5 | 0.4 | 0.2 | 0.0 | 0.4 | 
| 5 | 0.4 | 0.2 | 0.2 | 0.2 | 
### Table for method: 'stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.0 | 0.6 | 0.2 | 
| 1 | 0.2 | 0.2 | 0.4 | 0.2 | 
| 1 | 0.2 | 0.4 | 0.2 | 0.2 | 
| 1 | 0.2 | 0.6 | 0.0 | 0.2 | 
| 1 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 1 | 0.4 | 0.2 | 0.0 | 0.4 | 
| 3 | 0.2 | 0.0 | 0.4 | 0.4 | 
| 3 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 3 | 0.2 | 0.4 | 0.0 | 0.4 | 
| 3 | 0.4 | 0.0 | 0.0 | 0.6 | 
| 5 | 0.6 | 0.2 | 0.0 | 0.2 | 

