# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '2000' (decision based on smallest k) 
## Precision@k table: 
| k |1000 | 2000 | 3000 | 4000 | 5000 | 6000 | 7000 | 8000 | 9000 | 10000 | 11000 | 12000 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.188 | 0.25 | 0.246 | 0.228 | 0.232 | 0.187 | 0.122 | 0.17 | 0.154 | 0.144 | 0.164 | 0.225 | 
| 3 | 0.407 | 0.458 | 0.465 | 0.459 | 0.453 | 0.406 | 0.312 | 0.405 | 0.403 | 0.297 | 0.326 | 0.408 | 
| 5 | 0.567 | 0.596 | 0.566 | 0.607 | 0.648 | 0.603 | 0.453 | 0.585 | 0.569 | 0.47 | 0.457 | 0.525 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

