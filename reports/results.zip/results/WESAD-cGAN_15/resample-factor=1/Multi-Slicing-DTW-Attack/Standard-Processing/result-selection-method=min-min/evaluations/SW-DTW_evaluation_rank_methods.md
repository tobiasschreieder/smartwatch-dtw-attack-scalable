# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.15 | 0.175 | 0.162 |
| 3 | 0.379 | 0.379 | 0.379 |
| 5 | 0.531 | 0.538 | 0.534 |
| max@k | k = 15 | k = 15 | k = 15 |

