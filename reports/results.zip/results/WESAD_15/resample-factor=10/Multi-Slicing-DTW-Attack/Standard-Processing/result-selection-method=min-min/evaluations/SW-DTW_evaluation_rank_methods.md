# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.338 | 0.418 | 0.378 |
| 3 | 0.602 | 0.601 | 0.602 |
| 5 | 0.733 | 0.686 | 0.71 |
| max@k | k = 15 | k = 15 | k = 15 |

