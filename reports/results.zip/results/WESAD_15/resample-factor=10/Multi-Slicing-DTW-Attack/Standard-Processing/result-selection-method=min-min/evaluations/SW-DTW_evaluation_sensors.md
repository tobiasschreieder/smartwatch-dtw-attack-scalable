# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.669 | 0.203 | 0.091 | 0.567 | 0.602 | 0.422 | 0.841 | 0.136 | 0.432 | 0.39 | 0.399 | 0.728 | 0.573 | 0.334 | 0.549 | 
| 3 | 0.982 | 0.374 | 0.253 | 0.798 | 0.736 | 0.628 | 0.94 | 0.296 | 0.665 | 0.579 | 0.608 | 0.845 | 0.744 | 0.568 | 0.712 | 
| 5 | 1.0 | 0.497 | 0.383 | 0.899 | 0.836 | 0.711 | 0.971 | 0.406 | 0.747 | 0.662 | 0.707 | 0.892 | 0.805 | 0.667 | 0.794 | 
| max@k | k = 5 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

