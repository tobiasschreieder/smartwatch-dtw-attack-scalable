# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.529 | 0.307 |
| 3 | 0.72 | 0.481 |
| 5 | 0.8 | 0.573 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.418 | 0.462 |
| 3 | 0.601 | 1.0 |
| 5 | 0.686 | 0.732 |
| max@k | k = 15 | k = 15 |

