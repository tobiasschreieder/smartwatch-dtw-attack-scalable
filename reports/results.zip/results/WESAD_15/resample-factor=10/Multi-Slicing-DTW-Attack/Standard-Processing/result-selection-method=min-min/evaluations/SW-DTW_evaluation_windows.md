# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '100' (decision based on smallest k) 
## Precision@k table: 
| k |100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 1000 | 1100 | 1200 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.657 | 0.58 | 0.538 | 0.544 | 0.497 | 0.482 | 0.475 | 0.476 | 0.367 | 0.331 | 0.336 | 0.267 | 
| 3 | 0.829 | 0.788 | 0.752 | 0.736 | 0.69 | 0.666 | 0.645 | 0.631 | 0.545 | 0.548 | 0.492 | 0.461 | 
| 5 | 0.912 | 0.852 | 0.822 | 0.799 | 0.784 | 0.759 | 0.716 | 0.709 | 0.642 | 0.638 | 0.582 | 0.568 | 
| max@k | k = 12 | k = 13 | k = 13 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

