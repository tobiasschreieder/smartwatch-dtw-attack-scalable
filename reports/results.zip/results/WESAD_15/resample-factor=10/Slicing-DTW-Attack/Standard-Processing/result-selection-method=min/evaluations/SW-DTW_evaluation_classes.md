# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.978 | 0.978 |
| 3 | 0.997 | 0.996 |
| 5 | 1.0 | 0.998 |
| max@k | k = 5 | k = 8 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.978 | 0.978 |
| 3 | 0.996 | 1.0 |
| 5 | 0.999 | 0.999 |
| max@k | k = 6 | k = 6 |

