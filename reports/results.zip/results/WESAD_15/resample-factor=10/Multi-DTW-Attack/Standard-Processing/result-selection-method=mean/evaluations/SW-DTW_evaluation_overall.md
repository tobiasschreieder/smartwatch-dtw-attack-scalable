# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Calculated with test-window-size: '100' 
## Precision@k table: 
| k | DTW-results | sensor weighted | random guess |
|---|---|---|---|
| 1 | 0.188 | 0.473 | 0.067 |
| 3 | 0.366 | 0.667 | 0.2 |
| 5 | 0.521 | 0.82 | 0.333 |
| max@k | k = 15 | k = 8 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 1 | 0.2 | 0.4 | 0.2 | 0.2 | 
| 1 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 3 | 0.0 | 0.0 | 0.4 | 0.6 | 
| 3 | 0.2 | 0.0 | 0.2 | 0.6 | 
| 3 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 3 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 3 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 3 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 3 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 3 | 0.8 | 0.0 | 0.0 | 0.2 | 
| 5 | 0.4 | 0.0 | 0.2 | 0.4 | 
### Table for method: 'stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 3 | 0.8 | 0.2 | 0.0 | 0.0 | 
| 5 | 0.8 | 0.2 | 0.0 | 0.0 | 

