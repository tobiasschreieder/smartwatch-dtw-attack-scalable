# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.132 | 0.122 | 0.127 |
| 3 | 0.317 | 0.283 | 0.3 |
| 5 | 0.46 | 0.428 | 0.444 |
| max@k | k = 15 | k = 15 | k = 15 |

