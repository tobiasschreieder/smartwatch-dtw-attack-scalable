# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.173 | 0.067 | 0.094 | 0.202 | 0.076 | 0.144 | 0.328 | 0.06 | 0.087 | 0.168 | 0.105 | 0.098 | 0.229 | 0.072 | 0.141 | 
| 3 | 0.422 | 0.213 | 0.232 | 0.416 | 0.223 | 0.32 | 0.483 | 0.195 | 0.259 | 0.331 | 0.215 | 0.288 | 0.423 | 0.254 | 0.317 | 
| 5 | 0.578 | 0.373 | 0.378 | 0.571 | 0.432 | 0.457 | 0.584 | 0.334 | 0.404 | 0.469 | 0.379 | 0.475 | 0.567 | 0.399 | 0.415 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

