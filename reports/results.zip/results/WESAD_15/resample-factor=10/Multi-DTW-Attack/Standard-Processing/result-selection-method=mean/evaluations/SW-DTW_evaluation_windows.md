# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '100' (decision based on smallest k) 
## Precision@k table: 
| k |100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 1000 | 1100 | 1200 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.188 | 0.173 | 0.168 | 0.157 | 0.148 | 0.145 | 0.127 | 0.119 | 0.107 | 0.102 | 0.103 | 0.098 | 
| 3 | 0.366 | 0.346 | 0.339 | 0.316 | 0.321 | 0.309 | 0.297 | 0.293 | 0.287 | 0.27 | 0.267 | 0.261 | 
| 5 | 0.521 | 0.498 | 0.484 | 0.47 | 0.453 | 0.455 | 0.453 | 0.436 | 0.429 | 0.418 | 0.418 | 0.416 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

