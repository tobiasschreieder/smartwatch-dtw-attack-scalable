# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.145 | 0.11 |
| 3 | 0.334 | 0.237 |
| 5 | 0.502 | 0.383 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.128 | 0.135 |
| 3 | 0.285 | 1.0 |
| 5 | 0.443 | 0.466 |
| max@k | k = 15 | k = 15 |

