# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.139 | 0.128 | 0.133 |
| 3 | 0.347 | 0.286 | 0.316 |
| 5 | 0.502 | 0.443 | 0.472 |
| max@k | k = 15 | k = 15 | k = 15 |

