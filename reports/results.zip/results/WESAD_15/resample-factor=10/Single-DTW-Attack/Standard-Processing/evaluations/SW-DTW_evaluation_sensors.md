# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.191 | 0.08 | 0.064 | 0.214 | 0.093 | 0.117 | 0.296 | 0.075 | 0.069 | 0.126 | 0.136 | 0.1 | 0.157 | 0.128 | 0.174 | 
| 3 | 0.491 | 0.211 | 0.258 | 0.381 | 0.228 | 0.354 | 0.451 | 0.19 | 0.257 | 0.297 | 0.219 | 0.293 | 0.405 | 0.256 | 0.286 | 
| 5 | 0.652 | 0.372 | 0.426 | 0.509 | 0.408 | 0.518 | 0.57 | 0.37 | 0.416 | 0.45 | 0.399 | 0.49 | 0.584 | 0.407 | 0.426 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

