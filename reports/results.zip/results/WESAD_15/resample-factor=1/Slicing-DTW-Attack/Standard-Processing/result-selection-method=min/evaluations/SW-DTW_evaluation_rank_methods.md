# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.963 | 0.977 | 0.97 |
| 3 | 0.995 | 0.996 | 0.996 |
| 5 | 0.998 | 0.998 | 0.998 |
| max@k | k = 8 | k = 8 | k = 8 |

