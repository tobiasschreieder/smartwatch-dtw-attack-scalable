# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.177 | 0.081 | 0.064 | 0.198 | 0.091 | 0.116 | 0.268 | 0.075 | 0.083 | 0.107 | 0.137 | 0.101 | 0.123 | 0.124 | 0.162 | 
| 3 | 0.456 | 0.211 | 0.258 | 0.328 | 0.227 | 0.348 | 0.419 | 0.19 | 0.258 | 0.285 | 0.221 | 0.292 | 0.402 | 0.259 | 0.284 | 
| 5 | 0.66 | 0.371 | 0.431 | 0.444 | 0.409 | 0.519 | 0.514 | 0.37 | 0.411 | 0.462 | 0.402 | 0.467 | 0.567 | 0.404 | 0.42 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

