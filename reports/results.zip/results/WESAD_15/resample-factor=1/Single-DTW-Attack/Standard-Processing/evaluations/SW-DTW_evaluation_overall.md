# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Calculated with test-window-size: '1000' 
## Precision@k table: 
| k | DTW-results | sensor weighted | random guess |
|---|---|---|---|
| 1 | 0.182 | 0.427 | 0.067 |
| 3 | 0.343 | 0.627 | 0.2 |
| 5 | 0.506 | 0.707 | 0.333 |
| max@k | k = 15 | k = 8 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.2 | 0.0 | 0.4 | 0.4 | 
| 1 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 1 | 0.2 | 0.4 | 0.2 | 0.2 | 
| 1 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 1 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 3 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 5 | 0.0 | 0.0 | 0.4 | 0.6 | 
| 5 | 0.0 | 0.2 | 0.2 | 0.6 | 
| 5 | 0.0 | 0.4 | 0.2 | 0.4 | 
| 5 | 0.2 | 0.0 | 0.2 | 0.6 | 
| 5 | 0.2 | 0.0 | 0.4 | 0.4 | 
| 5 | 0.2 | 0.2 | 0.2 | 0.4 | 
| 5 | 0.2 | 0.4 | 0.2 | 0.2 | 
| 5 | 0.4 | 0.0 | 0.2 | 0.4 | 
| 5 | 0.4 | 0.0 | 0.4 | 0.2 | 
| 5 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 5 | 0.4 | 0.4 | 0.0 | 0.2 | 
| 5 | 0.6 | 0.0 | 0.2 | 0.2 | 
| 5 | 0.8 | 0.0 | 0.2 | 0.0 | 
### Table for method: 'stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.4 | 0.2 | 0.0 | 0.4 | 
| 1 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 1 | 0.4 | 0.2 | 0.4 | 0.0 | 
| 1 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 3 | 0.6 | 0.2 | 0.0 | 0.2 | 
| 5 | 0.8 | 0.2 | 0.0 | 0.0 | 

