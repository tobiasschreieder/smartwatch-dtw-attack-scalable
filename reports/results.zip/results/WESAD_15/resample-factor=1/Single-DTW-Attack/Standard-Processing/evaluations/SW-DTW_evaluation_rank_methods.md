# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.131 | 0.121 | 0.126 |
| 3 | 0.323 | 0.277 | 0.3 |
| 5 | 0.471 | 0.433 | 0.452 |
| max@k | k = 15 | k = 15 | k = 15 |

