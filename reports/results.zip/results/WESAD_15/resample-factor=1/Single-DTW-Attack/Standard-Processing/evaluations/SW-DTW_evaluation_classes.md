# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.136 | 0.106 |
| 3 | 0.324 | 0.231 |
| 5 | 0.493 | 0.373 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.121 | 0.127 |
| 3 | 0.278 | 1.0 |
| 5 | 0.433 | 0.457 |
| max@k | k = 15 | k = 15 |

