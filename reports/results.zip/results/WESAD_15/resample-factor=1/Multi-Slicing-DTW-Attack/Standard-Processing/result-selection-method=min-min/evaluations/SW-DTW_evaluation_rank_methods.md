# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.338 | 0.413 | 0.375 |
| 3 | 0.599 | 0.586 | 0.593 |
| 5 | 0.723 | 0.673 | 0.698 |
| max@k | k = 15 | k = 15 | k = 15 |

