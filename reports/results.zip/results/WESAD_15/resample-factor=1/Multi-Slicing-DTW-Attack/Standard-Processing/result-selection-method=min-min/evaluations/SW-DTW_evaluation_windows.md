# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '1000' (decision based on smallest k) 
## Precision@k table: 
| k |1000 | 2000 | 3000 | 4000 | 5000 | 6000 | 7000 | 8000 | 9000 | 10000 | 11000 | 12000 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.661 | 0.57 | 0.529 | 0.511 | 0.483 | 0.472 | 0.481 | 0.454 | 0.367 | 0.331 | 0.319 | 0.268 | 
| 3 | 0.812 | 0.782 | 0.74 | 0.716 | 0.663 | 0.657 | 0.642 | 0.612 | 0.521 | 0.526 | 0.479 | 0.436 | 
| 5 | 0.894 | 0.841 | 0.812 | 0.787 | 0.764 | 0.743 | 0.698 | 0.691 | 0.627 | 0.626 | 0.566 | 0.556 | 
| max@k | k = 12 | k = 13 | k = 13 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

