# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.516 | 0.31 |
| 3 | 0.701 | 0.472 |
| 5 | 0.783 | 0.562 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.413 | 0.454 |
| 3 | 0.587 | 1.0 |
| 5 | 0.673 | 0.717 |
| max@k | k = 15 | k = 15 |

