# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.68 | 0.219 | 0.087 | 0.533 | 0.611 | 0.425 | 0.861 | 0.136 | 0.41 | 0.376 | 0.387 | 0.693 | 0.551 | 0.317 | 0.522 | 
| 3 | 0.985 | 0.381 | 0.273 | 0.774 | 0.724 | 0.614 | 0.943 | 0.296 | 0.628 | 0.541 | 0.591 | 0.821 | 0.711 | 0.525 | 0.676 | 
| 5 | 0.994 | 0.488 | 0.389 | 0.851 | 0.809 | 0.691 | 0.971 | 0.423 | 0.723 | 0.644 | 0.703 | 0.884 | 0.771 | 0.653 | 0.756 | 
| max@k | k = 6 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

