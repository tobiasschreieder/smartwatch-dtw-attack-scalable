# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.122 | 0.114 | 0.118 |
| 3 | 0.295 | 0.27 | 0.282 |
| 5 | 0.435 | 0.418 | 0.426 |
| max@k | k = 15 | k = 15 | k = 15 |

