# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '1000' (decision based on smallest k) 
## Precision@k table: 
| k |1000 | 2000 | 3000 | 4000 | 5000 | 6000 | 7000 | 8000 | 9000 | 10000 | 11000 | 12000 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.182 | 0.163 | 0.159 | 0.144 | 0.136 | 0.127 | 0.113 | 0.108 | 0.102 | 0.102 | 0.098 | 0.095 | 
| 3 | 0.358 | 0.337 | 0.321 | 0.305 | 0.317 | 0.311 | 0.289 | 0.277 | 0.261 | 0.254 | 0.248 | 0.255 | 
| 5 | 0.509 | 0.491 | 0.467 | 0.46 | 0.444 | 0.44 | 0.431 | 0.426 | 0.425 | 0.412 | 0.417 | 0.427 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

