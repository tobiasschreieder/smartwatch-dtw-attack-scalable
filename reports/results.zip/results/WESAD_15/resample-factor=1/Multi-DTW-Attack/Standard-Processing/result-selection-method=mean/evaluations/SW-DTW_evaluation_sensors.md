# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.131 | 0.067 | 0.094 | 0.193 | 0.073 | 0.146 | 0.304 | 0.06 | 0.087 | 0.145 | 0.103 | 0.094 | 0.211 | 0.071 | 0.136 | 
| 3 | 0.373 | 0.213 | 0.232 | 0.372 | 0.222 | 0.32 | 0.46 | 0.191 | 0.257 | 0.31 | 0.215 | 0.287 | 0.406 | 0.252 | 0.31 | 
| 5 | 0.566 | 0.372 | 0.378 | 0.528 | 0.418 | 0.454 | 0.556 | 0.334 | 0.418 | 0.448 | 0.393 | 0.458 | 0.537 | 0.402 | 0.423 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

