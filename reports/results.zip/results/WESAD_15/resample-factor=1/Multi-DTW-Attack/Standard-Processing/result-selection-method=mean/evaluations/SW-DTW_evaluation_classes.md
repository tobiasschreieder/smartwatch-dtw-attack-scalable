# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.148 | 0.079 |
| 3 | 0.331 | 0.209 |
| 5 | 0.487 | 0.348 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.113 | 0.127 |
| 3 | 0.27 | 1.0 |
| 5 | 0.417 | 0.445 |
| max@k | k = 15 | k = 15 |

