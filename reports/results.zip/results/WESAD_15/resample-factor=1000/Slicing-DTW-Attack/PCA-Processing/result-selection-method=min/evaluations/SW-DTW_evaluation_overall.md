# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'pca-1' 
* Calculated with test-window-size: '5' 
## Precision@k table: 
| k | DTW-results | sensor weighted | random guess |
|---|---|---|---|
| 1 | 0.36 | 0.36 | 0.067 |
| 3 | 0.627 | 0.627 | 0.2 |
| 5 | 0.76 | 0.76 | 0.333 |
| max@k | k = 13 | k = 13 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | pca-1 | 
|---|---|
| 1 | 1.0 | 
| 3 | 1.0 | 
| 5 | 1.0 | 
### Table for method: 'stress': 
| k | pca-1 | 
|---|---|
| 1 | 1.0 | 
| 3 | 1.0 | 
| 5 | 1.0 | 

