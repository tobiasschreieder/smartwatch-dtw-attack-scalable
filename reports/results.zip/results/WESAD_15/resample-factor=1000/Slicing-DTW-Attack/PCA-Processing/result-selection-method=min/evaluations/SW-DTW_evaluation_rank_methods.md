# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.157 | 0.157 | 0.157 |
| 3 | 0.378 | 0.378 | 0.378 |
| 5 | 0.505 | 0.505 | 0.505 |
| max@k | k = 15 | k = 15 | k = 15 |

