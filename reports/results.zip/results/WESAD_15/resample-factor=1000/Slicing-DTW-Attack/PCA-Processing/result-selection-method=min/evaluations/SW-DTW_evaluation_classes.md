# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.237 | 0.078 |
| 3 | 0.47 | 0.285 |
| 5 | 0.618 | 0.391 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.158 | 0.189 |
| 3 | 0.377 | 1.0 |
| 5 | 0.504 | 0.55 |
| max@k | k = 15 | k = 15 |

