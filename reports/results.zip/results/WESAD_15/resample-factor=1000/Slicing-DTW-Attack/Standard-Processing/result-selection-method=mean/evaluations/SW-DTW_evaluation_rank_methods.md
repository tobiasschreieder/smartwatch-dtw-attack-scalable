# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.4 | 0.424 | 0.412 |
| 3 | 0.622 | 0.62 | 0.621 |
| 5 | 0.734 | 0.726 | 0.73 |
| max@k | k = 15 | k = 15 | k = 15 |

