# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.412 | 0.435 |
| 3 | 0.618 | 0.623 |
| 5 | 0.72 | 0.731 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.423 | 0.419 |
| 3 | 0.621 | 1.0 |
| 5 | 0.726 | 0.723 |
| max@k | k = 15 | k = 15 |

