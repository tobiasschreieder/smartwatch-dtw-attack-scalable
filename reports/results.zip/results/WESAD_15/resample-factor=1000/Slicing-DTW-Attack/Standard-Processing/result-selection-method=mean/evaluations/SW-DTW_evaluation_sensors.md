# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.209 | 0.169 | 0.395 | 0.483 | 0.385 | 0.615 | 0.212 | 0.361 | 0.253 | 0.424 | 0.557 | 0.443 | 0.291 | 0.488 | 
| 3 | 1.0 | 0.414 | 0.335 | 0.565 | 0.783 | 0.62 | 0.866 | 0.42 | 0.532 | 0.402 | 0.642 | 0.774 | 0.699 | 0.497 | 0.742 | 
| 5 | 1.0 | 0.549 | 0.462 | 0.662 | 0.881 | 0.754 | 0.938 | 0.526 | 0.66 | 0.574 | 0.787 | 0.854 | 0.775 | 0.617 | 0.811 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 13 | k = 13 | k = 9 | k = 15 | k = 15 | k = 15 | k = 12 | k = 11 | k = 12 | k = 15 | k = 13 | 

