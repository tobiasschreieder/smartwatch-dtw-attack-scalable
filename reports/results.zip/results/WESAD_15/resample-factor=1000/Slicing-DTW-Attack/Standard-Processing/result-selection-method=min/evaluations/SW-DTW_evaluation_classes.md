# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.999 | 0.999 |
| 3 | 1.0 | 1.0 |
| 5 | 1.0 | 1.0 |
| max@k | k = 2 | k = 2 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.999 | 0.999 |
| 3 | 1.0 | 1.0 |
| 5 | 1.0 | 1.0 |
| max@k | k = 2 | k = 2 |

