# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.709 | 0.272 |
| 3 | 0.922 | 0.481 |
| 5 | 0.97 | 0.6 |
| max@k | k = 9 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.49 | 0.578 |
| 3 | 0.702 | 1.0 |
| 5 | 0.785 | 0.859 |
| max@k | k = 15 | k = 15 |

