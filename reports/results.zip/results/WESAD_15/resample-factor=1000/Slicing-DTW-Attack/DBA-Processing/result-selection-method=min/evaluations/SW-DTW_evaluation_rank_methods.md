# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.491 | 0.491 | 0.491 |
| 3 | 0.702 | 0.702 | 0.702 |
| 5 | 0.785 | 0.785 | 0.785 |
| max@k | k = 15 | k = 15 | k = 15 |

