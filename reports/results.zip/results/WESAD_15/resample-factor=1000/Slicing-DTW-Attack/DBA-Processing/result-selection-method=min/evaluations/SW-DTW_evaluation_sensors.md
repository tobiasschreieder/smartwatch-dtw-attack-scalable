# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'dba' (decision based on smallest k) 
## Precision@k table: 
| k |dba | 
|---|---|
| 1 | 0.578 | 
| 3 | 0.79 | 
| 5 | 0.859 | 
| max@k | k = 15 | 

