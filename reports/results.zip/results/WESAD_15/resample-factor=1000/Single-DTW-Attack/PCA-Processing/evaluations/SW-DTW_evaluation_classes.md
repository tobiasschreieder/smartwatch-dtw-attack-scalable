# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.069 | 0.032 |
| 3 | 0.174 | 0.059 |
| 5 | 0.261 | 0.213 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.051 | 0.058 |
| 3 | 0.116 | 1.0 |
| 5 | 0.237 | 0.247 |
| max@k | k = 15 | k = 15 |

