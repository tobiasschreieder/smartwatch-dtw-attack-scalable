# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.05 | 0.05 | 0.05 |
| 3 | 0.117 | 0.117 | 0.117 |
| 5 | 0.237 | 0.237 | 0.237 |
| max@k | k = 15 | k = 15 | k = 15 |

