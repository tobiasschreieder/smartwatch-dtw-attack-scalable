# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.294 | 0.243 |
| 3 | 0.502 | 0.402 |
| 5 | 0.646 | 0.498 |
| max@k | k = 12 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.268 | 0.279 |
| 3 | 0.452 | 1.0 |
| 5 | 0.572 | 0.602 |
| max@k | k = 15 | k = 15 |

