# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.268 | 0.268 | 0.268 |
| 3 | 0.452 | 0.452 | 0.452 |
| 5 | 0.572 | 0.572 | 0.572 |
| max@k | k = 15 | k = 15 | k = 15 |

