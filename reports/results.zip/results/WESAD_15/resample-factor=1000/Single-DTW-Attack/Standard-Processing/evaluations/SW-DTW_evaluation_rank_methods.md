# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.277 | 0.272 | 0.274 |
| 3 | 0.505 | 0.476 | 0.49 |
| 5 | 0.631 | 0.626 | 0.629 |
| max@k | k = 15 | k = 15 | k = 15 |

