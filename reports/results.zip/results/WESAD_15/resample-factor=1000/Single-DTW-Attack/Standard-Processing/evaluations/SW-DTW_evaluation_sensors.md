# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.067 | 0.084 | 0.276 | 0.176 | 0.338 | 0.609 | 0.1 | 0.104 | 0.176 | 0.26 | 0.217 | 0.411 | 0.12 | 0.289 | 
| 3 | 1.0 | 0.217 | 0.25 | 0.465 | 0.539 | 0.648 | 0.887 | 0.186 | 0.259 | 0.429 | 0.54 | 0.603 | 0.69 | 0.285 | 0.569 | 
| 5 | 1.0 | 0.387 | 0.433 | 0.603 | 0.757 | 0.811 | 0.963 | 0.404 | 0.522 | 0.542 | 0.706 | 0.823 | 0.807 | 0.444 | 0.755 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 12 | k = 13 | k = 9 | k = 15 | k = 15 | k = 15 | k = 14 | k = 12 | k = 13 | k = 15 | k = 14 | 

