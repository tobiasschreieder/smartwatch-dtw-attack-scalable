# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.297 | 0.247 |
| 3 | 0.548 | 0.404 |
| 5 | 0.72 | 0.533 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.272 | 0.282 |
| 3 | 0.476 | 1.0 |
| 5 | 0.627 | 0.664 |
| max@k | k = 15 | k = 15 |

