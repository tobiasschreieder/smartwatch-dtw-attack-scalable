# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.108 | 0.108 | 0.108 |
| 3 | 0.308 | 0.308 | 0.308 |
| 5 | 0.492 | 0.492 | 0.492 |
| max@k | k = 15 | k = 15 | k = 15 |

