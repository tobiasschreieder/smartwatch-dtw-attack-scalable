# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.15 | 0.067 |
| 3 | 0.378 | 0.239 |
| 5 | 0.583 | 0.4 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.108 | 0.125 |
| 3 | 0.308 | 1.0 |
| 5 | 0.491 | 0.528 |
| max@k | k = 15 | k = 15 |

