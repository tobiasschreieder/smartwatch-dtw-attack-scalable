# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'pca-1' 
* Preferred test-window-size: '10' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.067 | 0.18 | 0.047 | 0.133 | 0.14 | 0.16 | 0.113 | 0.113 | 0.133 | 0.227 | 0.093 | 0.093 | 
| 3 | 0.34 | 0.36 | 0.267 | 0.407 | 0.333 | 0.287 | 0.267 | 0.333 | 0.427 | 0.46 | 0.207 | 0.347 | 
| 5 | 0.547 | 0.513 | 0.58 | 0.553 | 0.58 | 0.54 | 0.58 | 0.6 | 0.493 | 0.507 | 0.433 | 0.413 | 
| max@k | k = 15 | k = 14 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | 

