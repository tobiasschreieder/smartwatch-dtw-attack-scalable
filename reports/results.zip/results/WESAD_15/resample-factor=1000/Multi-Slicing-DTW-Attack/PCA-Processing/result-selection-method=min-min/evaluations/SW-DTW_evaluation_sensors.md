# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'pca-1' (decision based on smallest k) 
## Precision@k table: 
| k |pca-1 | 
|---|---|
| 1 | 0.125 | 
| 3 | 0.336 | 
| 5 | 0.528 | 
| max@k | k = 15 | 

