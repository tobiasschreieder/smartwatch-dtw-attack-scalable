# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'dba' (decision based on smallest k) 
## Precision@k table: 
| k |dba | 
|---|---|
| 1 | 0.548 | 
| 3 | 0.762 | 
| 5 | 0.884 | 
| max@k | k = 14 | 

