# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.481 | 0.481 | 0.481 |
| 3 | 0.689 | 0.689 | 0.689 |
| 5 | 0.822 | 0.822 | 0.822 |
| max@k | k = 14 | k = 14 | k = 14 |

