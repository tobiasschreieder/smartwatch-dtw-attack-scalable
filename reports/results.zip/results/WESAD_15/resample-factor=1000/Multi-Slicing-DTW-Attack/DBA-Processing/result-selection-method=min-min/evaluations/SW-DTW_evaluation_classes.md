# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.65 | 0.311 |
| 3 | 0.872 | 0.506 |
| 5 | 0.978 | 0.667 |
| max@k | k = 6 | k = 14 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.481 | 0.548 |
| 3 | 0.689 | 1.0 |
| 5 | 0.823 | 0.885 |
| max@k | k = 14 | k = 14 |

