# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'dba' 
* Preferred test-window-size: '11' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.307 | 0.407 | 0.473 | 0.68 | 0.56 | 0.54 | 0.567 | 0.547 | 0.547 | 0.573 | 0.713 | 0.667 | 
| 3 | 0.813 | 0.693 | 0.693 | 0.9 | 0.827 | 0.807 | 0.793 | 0.72 | 0.727 | 0.707 | 0.733 | 0.733 | 
| 5 | 0.873 | 0.873 | 0.853 | 0.94 | 0.94 | 0.92 | 0.92 | 0.94 | 0.813 | 0.86 | 0.84 | 0.84 | 
| max@k | k = 12 | k = 10 | k = 8 | k = 10 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | 

