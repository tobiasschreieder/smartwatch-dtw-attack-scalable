# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '6' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.24 | 0.288 | 0.305 | 0.309 | 0.306 | 0.316 | 0.292 | 0.292 | 0.293 | 0.288 | 0.294 | 0.284 | 
| 3 | 0.478 | 0.515 | 0.491 | 0.492 | 0.513 | 0.513 | 0.512 | 0.505 | 0.513 | 0.513 | 0.51 | 0.508 | 
| 5 | 0.639 | 0.676 | 0.648 | 0.623 | 0.618 | 0.623 | 0.631 | 0.628 | 0.637 | 0.644 | 0.647 | 0.651 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

