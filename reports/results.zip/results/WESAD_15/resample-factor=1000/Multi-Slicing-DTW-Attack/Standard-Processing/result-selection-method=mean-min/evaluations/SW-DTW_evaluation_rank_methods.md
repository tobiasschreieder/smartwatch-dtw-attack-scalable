# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.276 | 0.267 | 0.271 |
| 3 | 0.524 | 0.455 | 0.49 |
| 5 | 0.644 | 0.582 | 0.613 |
| max@k | k = 15 | k = 15 | k = 15 |

