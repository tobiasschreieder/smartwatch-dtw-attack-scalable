# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.33 | 0.205 |
| 3 | 0.58 | 0.33 |
| 5 | 0.724 | 0.44 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.268 | 0.292 |
| 3 | 0.455 | 1.0 |
| 5 | 0.582 | 0.639 |
| max@k | k = 15 | k = 15 |

