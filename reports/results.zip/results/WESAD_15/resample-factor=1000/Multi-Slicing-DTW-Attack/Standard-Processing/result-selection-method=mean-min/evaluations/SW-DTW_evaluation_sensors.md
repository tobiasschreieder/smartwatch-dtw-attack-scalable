# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.098 | 0.088 | 0.367 | 0.147 | 0.24 | 0.702 | 0.096 | 0.134 | 0.153 | 0.252 | 0.278 | 0.33 | 0.155 | 0.343 | 
| 3 | 1.0 | 0.161 | 0.229 | 0.655 | 0.462 | 0.505 | 0.894 | 0.303 | 0.311 | 0.339 | 0.458 | 0.64 | 0.638 | 0.407 | 0.579 | 
| 5 | 1.0 | 0.273 | 0.415 | 0.817 | 0.631 | 0.67 | 0.953 | 0.461 | 0.51 | 0.553 | 0.605 | 0.738 | 0.732 | 0.531 | 0.69 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 12 | k = 14 | k = 11 | k = 15 | k = 15 | k = 15 | k = 14 | k = 12 | k = 15 | k = 15 | k = 15 | 

