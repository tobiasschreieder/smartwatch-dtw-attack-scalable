# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.295 | 0.32 | 0.308 |
| 3 | 0.54 | 0.507 | 0.524 |
| 5 | 0.658 | 0.609 | 0.634 |
| max@k | k = 15 | k = 15 | k = 15 |

