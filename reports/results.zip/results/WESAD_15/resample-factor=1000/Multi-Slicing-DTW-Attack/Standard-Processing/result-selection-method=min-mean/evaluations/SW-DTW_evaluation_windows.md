# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '9' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.3 | 0.369 | 0.35 | 0.356 | 0.349 | 0.355 | 0.364 | 0.36 | 0.38 | 0.373 | 0.371 | 0.355 | 
| 3 | 0.531 | 0.551 | 0.548 | 0.564 | 0.562 | 0.574 | 0.573 | 0.564 | 0.553 | 0.547 | 0.532 | 0.543 | 
| 5 | 0.663 | 0.661 | 0.658 | 0.655 | 0.66 | 0.652 | 0.661 | 0.667 | 0.647 | 0.662 | 0.641 | 0.632 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

