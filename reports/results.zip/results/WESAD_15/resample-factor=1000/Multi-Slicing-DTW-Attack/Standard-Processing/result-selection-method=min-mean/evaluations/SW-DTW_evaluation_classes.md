# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.411 | 0.229 |
| 3 | 0.623 | 0.391 |
| 5 | 0.724 | 0.494 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.32 | 0.356 |
| 3 | 0.507 | 1.0 |
| 5 | 0.609 | 0.655 |
| max@k | k = 15 | k = 15 |

