# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.994 | 0.105 | 0.069 | 0.451 | 0.264 | 0.313 | 0.788 | 0.103 | 0.248 | 0.173 | 0.332 | 0.401 | 0.462 | 0.204 | 0.445 | 
| 3 | 1.0 | 0.22 | 0.218 | 0.719 | 0.501 | 0.584 | 0.963 | 0.283 | 0.407 | 0.433 | 0.602 | 0.564 | 0.693 | 0.45 | 0.664 | 
| 5 | 1.0 | 0.318 | 0.393 | 0.832 | 0.607 | 0.718 | 0.985 | 0.457 | 0.487 | 0.593 | 0.696 | 0.689 | 0.744 | 0.539 | 0.765 | 
| max@k | k = 2 | k = 15 | k = 15 | k = 15 | k = 14 | k = 14 | k = 8 | k = 15 | k = 15 | k = 15 | k = 14 | k = 14 | k = 13 | k = 15 | k = 14 | 

