# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.35 | 0.473 | 0.411 |
| 3 | 0.597 | 0.648 | 0.622 |
| 5 | 0.724 | 0.742 | 0.733 |
| max@k | k = 15 | k = 15 | k = 15 |

