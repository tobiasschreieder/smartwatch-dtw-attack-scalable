# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.571 | 0.374 |
| 3 | 0.758 | 0.537 |
| 5 | 0.842 | 0.642 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.472 | 0.512 |
| 3 | 0.647 | 1.0 |
| 5 | 0.742 | 0.782 |
| max@k | k = 15 | k = 15 |

