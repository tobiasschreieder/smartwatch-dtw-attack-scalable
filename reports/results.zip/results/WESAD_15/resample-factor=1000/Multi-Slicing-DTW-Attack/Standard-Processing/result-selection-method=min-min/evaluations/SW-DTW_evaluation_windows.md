# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '3' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.588 | 0.6 | 0.606 | 0.565 | 0.549 | 0.547 | 0.52 | 0.475 | 0.453 | 0.431 | 0.427 | 0.384 | 
| 3 | 0.765 | 0.771 | 0.772 | 0.769 | 0.752 | 0.72 | 0.695 | 0.673 | 0.62 | 0.622 | 0.595 | 0.549 | 
| 5 | 0.856 | 0.858 | 0.845 | 0.829 | 0.814 | 0.813 | 0.788 | 0.766 | 0.722 | 0.729 | 0.706 | 0.659 | 
| max@k | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

