# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.991 | 0.174 | 0.045 | 0.547 | 0.701 | 0.508 | 0.923 | 0.077 | 0.415 | 0.297 | 0.506 | 0.822 | 0.715 | 0.3 | 0.66 | 
| 3 | 1.0 | 0.351 | 0.172 | 0.793 | 0.894 | 0.758 | 0.975 | 0.197 | 0.692 | 0.524 | 0.799 | 0.91 | 0.873 | 0.562 | 0.875 | 
| 5 | 1.0 | 0.471 | 0.307 | 0.903 | 0.947 | 0.874 | 0.987 | 0.358 | 0.783 | 0.707 | 0.902 | 0.96 | 0.92 | 0.676 | 0.936 | 
| max@k | k = 2 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 8 | k = 15 | k = 15 | k = 15 | k = 15 | k = 14 | k = 14 | k = 15 | k = 15 | 

