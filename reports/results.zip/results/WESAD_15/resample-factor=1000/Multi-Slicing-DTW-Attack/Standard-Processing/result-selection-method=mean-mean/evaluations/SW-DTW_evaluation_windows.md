# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '2' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.324 | 0.363 | 0.346 | 0.346 | 0.342 | 0.334 | 0.323 | 0.326 | 0.337 | 0.332 | 0.332 | 0.324 | 
| 3 | 0.558 | 0.543 | 0.547 | 0.544 | 0.54 | 0.536 | 0.538 | 0.53 | 0.538 | 0.527 | 0.532 | 0.54 | 
| 5 | 0.692 | 0.656 | 0.648 | 0.645 | 0.639 | 0.634 | 0.642 | 0.64 | 0.648 | 0.659 | 0.651 | 0.642 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

