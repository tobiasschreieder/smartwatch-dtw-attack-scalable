# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.067 | 0.084 | 0.396 | 0.243 | 0.306 | 0.662 | 0.122 | 0.178 | 0.209 | 0.281 | 0.386 | 0.437 | 0.285 | 0.382 | 
| 3 | 1.0 | 0.202 | 0.263 | 0.685 | 0.505 | 0.585 | 0.905 | 0.279 | 0.377 | 0.46 | 0.536 | 0.583 | 0.652 | 0.442 | 0.618 | 
| 5 | 1.0 | 0.319 | 0.45 | 0.797 | 0.584 | 0.656 | 0.963 | 0.487 | 0.508 | 0.57 | 0.66 | 0.753 | 0.723 | 0.555 | 0.721 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 12 | k = 14 | k = 10 | k = 15 | k = 15 | k = 15 | k = 14 | k = 12 | k = 15 | k = 15 | k = 15 | 

