# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.394 | 0.2 |
| 3 | 0.625 | 0.339 |
| 5 | 0.733 | 0.456 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.297 | 0.336 |
| 3 | 0.482 | 1.0 |
| 5 | 0.595 | 0.65 |
| max@k | k = 15 | k = 15 |

