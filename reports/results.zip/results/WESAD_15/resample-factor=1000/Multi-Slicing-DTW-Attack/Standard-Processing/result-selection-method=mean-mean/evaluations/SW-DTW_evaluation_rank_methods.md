# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.292 | 0.297 | 0.294 |
| 3 | 0.531 | 0.482 | 0.506 |
| 5 | 0.642 | 0.594 | 0.618 |
| max@k | k = 15 | k = 15 | k = 15 |

