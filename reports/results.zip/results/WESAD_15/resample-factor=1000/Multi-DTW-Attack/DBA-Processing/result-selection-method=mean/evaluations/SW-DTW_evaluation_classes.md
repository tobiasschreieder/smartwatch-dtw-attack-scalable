# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.289 | 0.2 |
| 3 | 0.528 | 0.378 |
| 5 | 0.661 | 0.506 |
| max@k | k = 9 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.244 | 0.262 |
| 3 | 0.453 | 1.0 |
| 5 | 0.584 | 0.615 |
| max@k | k = 15 | k = 15 |

