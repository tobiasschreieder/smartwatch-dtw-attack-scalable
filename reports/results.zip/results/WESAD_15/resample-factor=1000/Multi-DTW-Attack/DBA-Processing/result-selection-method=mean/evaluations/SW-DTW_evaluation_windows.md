# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'dba' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.293 | 0.293 | 0.293 | 0.293 | 0.293 | 0.293 | 0.293 | 0.247 | 0.247 | 0.2 | 0.2 | 0.2 | 
| 3 | 0.587 | 0.56 | 0.54 | 0.52 | 0.52 | 0.427 | 0.427 | 0.427 | 0.447 | 0.447 | 0.447 | 0.447 | 
| 5 | 0.713 | 0.693 | 0.713 | 0.693 | 0.627 | 0.607 | 0.587 | 0.54 | 0.54 | 0.54 | 0.56 | 0.56 | 
| max@k | k = 14 | k = 15 | k = 15 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | k = 13 | k = 13 | k = 13 | 

