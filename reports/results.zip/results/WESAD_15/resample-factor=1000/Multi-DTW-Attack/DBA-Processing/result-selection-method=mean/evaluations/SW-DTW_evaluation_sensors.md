# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'dba' (decision based on smallest k) 
## Precision@k table: 
| k |dba | 
|---|---|
| 1 | 0.262 | 
| 3 | 0.483 | 
| 5 | 0.614 | 
| max@k | k = 15 | 

