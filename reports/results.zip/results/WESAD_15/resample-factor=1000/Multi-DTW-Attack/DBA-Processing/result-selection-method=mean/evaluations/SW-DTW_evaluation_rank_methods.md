# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.244 | 0.244 | 0.244 |
| 3 | 0.453 | 0.453 | 0.453 |
| 5 | 0.583 | 0.583 | 0.583 |
| max@k | k = 15 | k = 15 | k = 15 |

