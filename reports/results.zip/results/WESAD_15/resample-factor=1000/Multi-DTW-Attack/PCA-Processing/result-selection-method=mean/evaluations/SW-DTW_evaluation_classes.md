# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.122 | 0.034 |
| 3 | 0.217 | 0.061 |
| 5 | 0.317 | 0.189 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.078 | 0.096 |
| 3 | 0.139 | 1.0 |
| 5 | 0.253 | 0.279 |
| max@k | k = 15 | k = 15 |

