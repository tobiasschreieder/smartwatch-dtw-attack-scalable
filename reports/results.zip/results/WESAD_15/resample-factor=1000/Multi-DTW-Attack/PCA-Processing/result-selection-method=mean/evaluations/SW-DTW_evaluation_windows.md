# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'pca-1' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.16 | 0.16 | 0.067 | 0.113 | 0.113 | 0.113 | 0.093 | 0.093 | 0.093 | 0.047 | 0.047 | 0.047 | 
| 3 | 0.267 | 0.207 | 0.227 | 0.207 | 0.207 | 0.207 | 0.207 | 0.187 | 0.093 | 0.047 | 0.093 | 0.093 | 
| 5 | 0.353 | 0.353 | 0.313 | 0.293 | 0.273 | 0.293 | 0.247 | 0.293 | 0.253 | 0.207 | 0.207 | 0.253 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

