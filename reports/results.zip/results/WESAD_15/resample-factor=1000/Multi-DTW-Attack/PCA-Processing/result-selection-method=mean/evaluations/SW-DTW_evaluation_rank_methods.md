# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.078 | 0.078 | 0.078 |
| 3 | 0.139 | 0.139 | 0.139 |
| 5 | 0.253 | 0.253 | 0.253 |
| max@k | k = 15 | k = 15 | k = 15 |

