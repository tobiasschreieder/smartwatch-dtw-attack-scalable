# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.295 | 0.287 | 0.291 | 0.288 | 0.286 | 0.272 | 0.273 | 0.271 | 0.26 | 0.251 | 0.254 | 0.237 | 
| 3 | 0.544 | 0.531 | 0.523 | 0.524 | 0.512 | 0.512 | 0.495 | 0.487 | 0.473 | 0.455 | 0.452 | 0.444 | 
| 5 | 0.7 | 0.702 | 0.668 | 0.66 | 0.666 | 0.65 | 0.656 | 0.642 | 0.617 | 0.61 | 0.602 | 0.591 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

