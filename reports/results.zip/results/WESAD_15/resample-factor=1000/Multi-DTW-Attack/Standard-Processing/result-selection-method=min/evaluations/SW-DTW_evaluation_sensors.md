# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.067 | 0.095 | 0.209 | 0.181 | 0.343 | 0.608 | 0.065 | 0.09 | 0.155 | 0.249 | 0.221 | 0.412 | 0.089 | 0.297 | 
| 3 | 1.0 | 0.215 | 0.233 | 0.473 | 0.557 | 0.662 | 0.839 | 0.18 | 0.26 | 0.399 | 0.518 | 0.597 | 0.648 | 0.269 | 0.59 | 
| 5 | 1.0 | 0.383 | 0.406 | 0.587 | 0.754 | 0.783 | 0.965 | 0.374 | 0.487 | 0.533 | 0.71 | 0.779 | 0.776 | 0.432 | 0.733 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 12 | k = 12 | k = 9 | k = 15 | k = 15 | k = 15 | k = 13 | k = 11 | k = 13 | k = 15 | k = 13 | 

