# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.288 | 0.235 |
| 3 | 0.539 | 0.395 |
| 5 | 0.699 | 0.527 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.261 | 0.272 |
| 3 | 0.467 | 1.0 |
| 5 | 0.613 | 0.647 |
| max@k | k = 15 | k = 15 |

