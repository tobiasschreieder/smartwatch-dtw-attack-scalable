# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.264 | 0.264 | 0.264 |
| 3 | 0.485 | 0.47 | 0.478 |
| 5 | 0.619 | 0.609 | 0.614 |
| max@k | k = 15 | k = 15 | k = 15 |

