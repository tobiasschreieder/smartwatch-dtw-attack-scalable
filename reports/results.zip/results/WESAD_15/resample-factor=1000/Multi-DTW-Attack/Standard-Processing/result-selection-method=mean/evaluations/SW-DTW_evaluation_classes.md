# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.304 | 0.224 |
| 3 | 0.553 | 0.387 |
| 5 | 0.7 | 0.519 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.264 | 0.28 |
| 3 | 0.47 | 1.0 |
| 5 | 0.609 | 0.646 |
| max@k | k = 15 | k = 15 |

