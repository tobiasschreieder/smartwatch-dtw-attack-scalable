# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+acc+temp' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.309 | 0.299 | 0.308 | 0.296 | 0.294 | 0.278 | 0.272 | 0.272 | 0.264 | 0.261 | 0.261 | 0.243 | 
| 3 | 0.561 | 0.534 | 0.528 | 0.524 | 0.513 | 0.507 | 0.505 | 0.498 | 0.488 | 0.469 | 0.461 | 0.455 | 
| 5 | 0.696 | 0.692 | 0.686 | 0.669 | 0.668 | 0.642 | 0.646 | 0.637 | 0.619 | 0.607 | 0.598 | 0.59 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

