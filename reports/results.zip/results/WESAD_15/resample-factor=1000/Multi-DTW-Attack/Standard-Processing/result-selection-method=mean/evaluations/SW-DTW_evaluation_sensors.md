# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 0.067 | 0.104 | 0.268 | 0.176 | 0.335 | 0.637 | 0.065 | 0.094 | 0.189 | 0.233 | 0.213 | 0.44 | 0.083 | 0.29 | 
| 3 | 1.0 | 0.215 | 0.233 | 0.485 | 0.555 | 0.656 | 0.878 | 0.194 | 0.26 | 0.424 | 0.528 | 0.614 | 0.655 | 0.28 | 0.574 | 
| 5 | 1.0 | 0.387 | 0.383 | 0.634 | 0.757 | 0.762 | 0.958 | 0.359 | 0.482 | 0.538 | 0.698 | 0.81 | 0.77 | 0.412 | 0.737 | 
| max@k | k = 1 | k = 15 | k = 15 | k = 15 | k = 12 | k = 12 | k = 10 | k = 15 | k = 15 | k = 15 | k = 13 | k = 11 | k = 13 | k = 15 | k = 13 | 

