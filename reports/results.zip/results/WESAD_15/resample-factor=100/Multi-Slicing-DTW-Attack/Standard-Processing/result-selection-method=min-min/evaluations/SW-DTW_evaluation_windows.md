# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '10' (decision based on smallest k) 
## Precision@k table: 
| k |10 | 20 | 30 | 40 | 50 | 60 | 70 | 80 | 90 | 100 | 110 | 120 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.636 | 0.579 | 0.565 | 0.564 | 0.538 | 0.536 | 0.526 | 0.481 | 0.438 | 0.389 | 0.382 | 0.361 | 
| 3 | 0.818 | 0.75 | 0.76 | 0.757 | 0.748 | 0.707 | 0.704 | 0.685 | 0.622 | 0.617 | 0.569 | 0.527 | 
| 5 | 0.885 | 0.836 | 0.84 | 0.828 | 0.815 | 0.804 | 0.797 | 0.78 | 0.732 | 0.723 | 0.675 | 0.639 | 
| max@k | k = 13 | k = 13 | k = 14 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

