# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.35 | 0.459 | 0.405 |
| 3 | 0.607 | 0.643 | 0.625 |
| 5 | 0.73 | 0.738 | 0.734 |
| max@k | k = 15 | k = 15 | k = 15 |

