# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.87 | 0.192 | 0.052 | 0.566 | 0.637 | 0.447 | 0.913 | 0.106 | 0.439 | 0.334 | 0.468 | 0.795 | 0.697 | 0.324 | 0.653 | 
| 3 | 1.0 | 0.344 | 0.193 | 0.812 | 0.848 | 0.744 | 0.967 | 0.254 | 0.7 | 0.588 | 0.726 | 0.896 | 0.835 | 0.6 | 0.826 | 
| 5 | 1.0 | 0.491 | 0.324 | 0.904 | 0.935 | 0.823 | 0.983 | 0.432 | 0.784 | 0.692 | 0.868 | 0.941 | 0.897 | 0.705 | 0.914 | 
| max@k | k = 3 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 9 | k = 15 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | 

