# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.992 | 0.989 |
| 3 | 1.0 | 0.999 |
| 5 | 1.0 | 1.0 |
| max@k | k = 2 | k = 4 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.99 | 0.991 |
| 3 | 1.0 | 1.0 |
| 5 | 1.0 | 1.0 |
| max@k | k = 3 | k = 3 |

