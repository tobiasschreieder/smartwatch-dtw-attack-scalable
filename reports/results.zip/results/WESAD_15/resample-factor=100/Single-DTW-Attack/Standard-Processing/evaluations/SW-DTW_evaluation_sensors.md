# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.501 | 0.07 | 0.067 | 0.244 | 0.158 | 0.228 | 0.468 | 0.073 | 0.073 | 0.142 | 0.218 | 0.192 | 0.366 | 0.129 | 0.243 | 
| 3 | 0.921 | 0.217 | 0.256 | 0.42 | 0.415 | 0.566 | 0.802 | 0.189 | 0.257 | 0.327 | 0.428 | 0.472 | 0.639 | 0.262 | 0.469 | 
| 5 | 0.956 | 0.384 | 0.429 | 0.565 | 0.617 | 0.694 | 0.917 | 0.376 | 0.458 | 0.508 | 0.616 | 0.671 | 0.735 | 0.43 | 0.674 | 
| max@k | k = 8 | k = 15 | k = 15 | k = 15 | k = 13 | k = 15 | k = 10 | k = 15 | k = 15 | k = 15 | k = 14 | k = 13 | k = 13 | k = 15 | k = 14 | 

