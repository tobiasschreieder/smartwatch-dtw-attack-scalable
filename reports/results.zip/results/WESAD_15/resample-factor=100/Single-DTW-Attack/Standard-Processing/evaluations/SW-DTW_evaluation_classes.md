# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.226 | 0.178 |
| 3 | 0.483 | 0.348 |
| 5 | 0.647 | 0.497 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.202 | 0.212 |
| 3 | 0.415 | 1.0 |
| 5 | 0.572 | 0.602 |
| max@k | k = 15 | k = 15 |

