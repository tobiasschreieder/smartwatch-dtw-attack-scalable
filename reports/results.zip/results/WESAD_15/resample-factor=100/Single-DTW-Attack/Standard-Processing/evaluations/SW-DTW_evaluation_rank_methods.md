# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.21 | 0.202 | 0.206 |
| 3 | 0.477 | 0.416 | 0.446 |
| 5 | 0.61 | 0.572 | 0.591 |
| max@k | k = 15 | k = 15 | k = 15 |

