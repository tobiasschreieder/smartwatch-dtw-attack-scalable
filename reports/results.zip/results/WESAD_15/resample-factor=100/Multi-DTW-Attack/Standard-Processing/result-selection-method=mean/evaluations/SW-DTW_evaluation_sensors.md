# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.486 | 0.067 | 0.091 | 0.228 | 0.146 | 0.218 | 0.466 | 0.06 | 0.085 | 0.188 | 0.19 | 0.194 | 0.369 | 0.076 | 0.222 | 
| 3 | 0.916 | 0.217 | 0.233 | 0.437 | 0.442 | 0.544 | 0.732 | 0.196 | 0.26 | 0.35 | 0.417 | 0.497 | 0.619 | 0.269 | 0.492 | 
| 5 | 0.989 | 0.38 | 0.378 | 0.602 | 0.654 | 0.679 | 0.903 | 0.338 | 0.419 | 0.509 | 0.6 | 0.67 | 0.691 | 0.403 | 0.649 | 
| max@k | k = 7 | k = 15 | k = 15 | k = 15 | k = 12 | k = 14 | k = 11 | k = 15 | k = 15 | k = 15 | k = 13 | k = 12 | k = 13 | k = 15 | k = 13 | 

