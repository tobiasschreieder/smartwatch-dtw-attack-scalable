# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.229 | 0.152 |
| 3 | 0.486 | 0.339 |
| 5 | 0.64 | 0.475 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.191 | 0.206 |
| 3 | 0.412 | 1.0 |
| 5 | 0.557 | 0.59 |
| max@k | k = 15 | k = 15 |

