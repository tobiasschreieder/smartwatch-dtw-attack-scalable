# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.199 | 0.19 | 0.195 |
| 3 | 0.447 | 0.412 | 0.43 |
| 5 | 0.596 | 0.558 | 0.577 |
| max@k | k = 15 | k = 15 | k = 15 |

