# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '10' (decision based on smallest k) 
## Precision@k table: 
| k |10 | 20 | 30 | 40 | 50 | 60 | 70 | 80 | 90 | 100 | 110 | 120 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.238 | 0.234 | 0.231 | 0.229 | 0.219 | 0.202 | 0.207 | 0.198 | 0.189 | 0.189 | 0.176 | 0.156 | 
| 3 | 0.489 | 0.49 | 0.46 | 0.456 | 0.466 | 0.452 | 0.446 | 0.436 | 0.416 | 0.403 | 0.392 | 0.39 | 
| 5 | 0.643 | 0.637 | 0.627 | 0.618 | 0.609 | 0.6 | 0.591 | 0.571 | 0.56 | 0.556 | 0.546 | 0.532 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

