# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.002 | 0.001 | 0.001 | 0.002 | 0.003 | 0.002 | 0.004 | 0.001 | 0.003 | 0.002 | 0.003 | 0.002 | 0.003 | 0.001 | 0.003 | 
| 3 | 0.007 | 0.005 | 0.004 | 0.004 | 0.007 | 0.006 | 0.008 | 0.005 | 0.004 | 0.003 | 0.006 | 0.009 | 0.009 | 0.005 | 0.007 | 
| 5 | 0.014 | 0.007 | 0.005 | 0.005 | 0.012 | 0.013 | 0.015 | 0.006 | 0.008 | 0.005 | 0.01 | 0.012 | 0.014 | 0.007 | 0.01 | 
| max@k | k = 985 | k = 999 | k = 1000 | k = 1000 | k = 990 | k = 992 | k = 995 | k = 1000 | k = 999 | k = 1000 | k = 992 | k = 994 | k = 990 | k = 1000 | k = 996 | 

