# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+acc' 
* Preferred test-window-size: '4' (decision based on smallest k) 
## Precision@k table: 
| k |4 | 
|---|---|
| 1 | 0.002 | 
| 3 | 0.006 | 
| 5 | 0.01 | 
| max@k | k = 999 | 

