# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.002 | 0.002 | 0.002 |
| 3 | 0.006 | 0.006 | 0.006 |
| 5 | 0.01 | 0.009 | 0.009 |
| max@k | k = 999 | k = 999 | k = 999 |

