# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.666 | 0.934 | 0.8 |
| 3 | 0.736 | 0.935 | 0.835 |
| 5 | 0.767 | 0.936 | 0.851 |
| max@k | k = 775 | k = 775 | k = 775 |

