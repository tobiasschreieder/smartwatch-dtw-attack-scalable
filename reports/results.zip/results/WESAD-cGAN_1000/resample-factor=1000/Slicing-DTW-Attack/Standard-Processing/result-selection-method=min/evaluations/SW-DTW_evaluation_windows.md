# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'acc' 
* Preferred test-window-size: '28' (decision based on smallest k) 
## Precision@k table: 
| k |28 | 
|---|---|
| 1 | 0.934 | 
| 3 | 0.935 | 
| 5 | 0.936 | 
| max@k | k = 773 | 

