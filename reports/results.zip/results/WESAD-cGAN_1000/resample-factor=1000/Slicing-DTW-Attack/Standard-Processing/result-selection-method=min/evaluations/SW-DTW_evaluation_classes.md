# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.934 | 0.934 |
| 3 | 0.935 | 0.935 |
| 5 | 0.936 | 0.935 |
| max@k | k = 770 | k = 807 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.934 | 0.934 |
| 3 | 0.935 | 1.0 |
| 5 | 0.935 | 0.936 |
| max@k | k = 770 | k = 770 |

