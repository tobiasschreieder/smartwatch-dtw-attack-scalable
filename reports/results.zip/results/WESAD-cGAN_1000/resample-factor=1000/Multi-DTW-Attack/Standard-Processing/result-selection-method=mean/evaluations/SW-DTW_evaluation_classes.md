# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.002 | 0.003 |
| 3 | 0.005 | 0.006 |
| 5 | 0.009 | 0.01 |
| max@k | k = 1000 | k = 1000 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.003 | 0.002 |
| 3 | 0.005 | 1.0 |
| 5 | 0.009 | 0.009 |
| max@k | k = 1000 | k = 1000 |

