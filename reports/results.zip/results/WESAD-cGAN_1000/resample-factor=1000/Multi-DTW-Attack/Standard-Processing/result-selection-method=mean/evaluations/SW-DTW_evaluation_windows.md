# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp' 
* Preferred test-window-size: '5' (decision based on smallest k) 
## Precision@k table: 
| k |5 | 
|---|---|
| 1 | 0.002 | 
| 3 | 0.005 | 
| 5 | 0.009 | 
| max@k | k = 1000 | 

