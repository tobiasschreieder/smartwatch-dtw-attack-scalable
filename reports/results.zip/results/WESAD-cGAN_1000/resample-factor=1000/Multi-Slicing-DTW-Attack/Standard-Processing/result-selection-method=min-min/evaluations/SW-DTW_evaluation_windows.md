# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda' 
* Preferred test-window-size: '9' (decision based on smallest k) 
## Precision@k table: 
| k |9 | 
|---|---|
| 1 | 0.004 | 
| 3 | 0.012 | 
| 5 | 0.019 | 
| max@k | k = 998 | 

