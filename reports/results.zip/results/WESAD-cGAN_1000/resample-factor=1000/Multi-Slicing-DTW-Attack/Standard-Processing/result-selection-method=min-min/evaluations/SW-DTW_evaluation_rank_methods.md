# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.004 | 0.004 | 0.004 |
| 3 | 0.011 | 0.01 | 0.01 |
| 5 | 0.017 | 0.016 | 0.017 |
| max@k | k = 998 | k = 998 | k = 998 |

