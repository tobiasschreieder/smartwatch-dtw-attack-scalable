# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.005 | 0.002 |
| 3 | 0.014 | 0.006 |
| 5 | 0.022 | 0.01 |
| max@k | k = 998 | k = 999 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.004 | 0.004 |
| 3 | 0.01 | 1.0 |
| 5 | 0.016 | 0.019 |
| max@k | k = 998 | k = 998 |

